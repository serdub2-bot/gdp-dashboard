FM2008 8.0.2 — Russian roster-link probe on flag-4 parent baseline
====================================================================

This is a controlled diagnostic probe, not a confirmed playable fix.
The included fm.exe is copied byte-for-byte from the existing flag-4
parent-registration probe (8051008 / tier 2 / flag 4). That baseline was
tested in-game: Russia and its five zone names appeared, but clubs did not.
This package changes only TEAM+0x54 for 21 exact-name A5-form roster rows
in both DB files; it does not alter COMP levels, zone parameters, rules,
registration code, or other TEAM formats. The intent is to test whether
these serialized roster-to-COMP links affect team loading on that baseline.

Scope limits: exact A5 rows were found for only 21 of 44 resolved roster IDs.
The other 23 resolved IDs (and roster names without exact DB IDs) are left
unchanged. The field assignment is a probe, not proof that this alone controls
eligibility. No game run with this combined package has confirmed an outcome.
Spain B and Norway are comparison cases for grouped competition structure,
not evidence that Russian eligibility uses an identical DB rule.

Install only into a COPY of FM2008 8.0.2. Back up fm.exe and both DB files.
Extract with paths preserved, clear the cache, and start a NEW game.
Rollback by restoring the three original files. Do not use on other versions.

TEAM edits (ID; zone; COMP ID; slot; old +0x54 bytes; new bytes):
1521; Юг; 130490; 181; 00 00 00 00; 00 00 00 b5
1531; Юг; 130490; 181; 00 00 00 00; 00 00 00 b5
130506; Восток; 130491; 182; 00 00 ec 00; 00 00 00 b6
130507; Центр; 130489; 180; 00 00 c4 00; 00 00 00 b4
130517; Запад; 130488; 179; 00 00 2c 00; 00 00 00 b3
130523; Запад; 130488; 179; 00 00 24 00; 00 00 00 b3
130532; Юг; 130490; 181; 00 00 08 00; 00 00 00 b5
130534; Юг; 130490; 181; 00 00 48 00; 00 00 00 b5
130546; Юг; 130490; 181; 00 00 00 00; 00 00 00 b5
130550; Урал-Поволжье; 8055759; 942; 00 00 00 00; 00 00 03 ae
130553; Урал-Поволжье; 8055759; 942; 00 00 00 00; 00 00 03 ae
130554; Восток; 130491; 182; 00 00 00 00; 00 00 00 b6
130560; Восток; 130491; 182; 00 00 00 00; 00 00 00 b6
476489; Запад; 130488; 179; 00 00 48 00; 00 00 00 b3
477171; Восток; 130491; 182; 00 00 00 00; 00 00 00 b6
477394; Центр; 130489; 180; 00 00 00 00; 00 00 00 b4
477429; Запад; 130488; 179; 00 00 00 00; 00 00 00 b3
477514; Урал-Поволжье; 8055759; 942; 00 00 00 00; 00 00 03 ae
483843; Восток; 130491; 182; 00 00 00 00; 00 00 00 b6
483847; Центр; 130489; 180; 00 00 00 00; 00 00 00 b4
1301102; Юг; 130490; 181; 00 00 40 00; 00 00 00 b5

SHA256:
444eb7924f5992a1e30f6abf944a2877d25f369f6a17fdbe4272eb36b152e7b9  fm.exe
0a7670d6ceb42948e16067a6d9e24664714415cf1ce17b525ea9a521a40c99a1  data/db/802/client_db.dat
fde77521542d3f712e7cce58ec3eced43adb2c46a19324c94754d6d126b1c627  data/db/802/server_db.dat
